#!/bin/bash

# Generate FIGlet banner for "PSYCHOMONG"
figlet PSYCHOMONG

web=$1
echo $OF
if [ $web == "-h" ]; then
    echo "Usage: ./psychomong website.com"
else
    ./subdomainer.sh -t $web -f true
    cd $web
    cd $(date +"%m-%d-%Y")
    nuclei -t /root/nuclei-templates/ -l all-live.txt -es info -o nucleiall.txt
    cat all.txt | gauplus -subs -b png,jpg,gif,jpeg,swf,woff,gif,svg -o allUrls.txt ; cat allUrls.txt | httpx -mc 200,403 -o liveallurls.txt
fi
