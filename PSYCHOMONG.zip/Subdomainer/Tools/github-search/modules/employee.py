
class Employee:
    tested = 0
    url = ''
    name = ''
    pseudo = ''
    email = ''
    company = ''
    job = ''
    orgs = []
    repo = 0
    altlogins = []
    ghaccount = {}
    ghsearch = {}
